import express from "express";
import dotenv from "dotenv";
dotenv.config();
const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));
app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.AI_API_KEY || !process.env.AI_BASE_URL || !process.env.AI_MODEL) {
      return res.status(503).json({ error: "Sunucu AI ayarları eksik. .env dosyasını yapılandır." });
    }
    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const safeMessages = messages.slice(-20).filter(m =>
      m && ["user", "assistant"].includes(m.role) && typeof m.content === "string"
    ).map(m => ({ role: m.role, content: m.content.slice(0, 8000) }));
    const response = await fetch(`${process.env.AI_BASE_URL.replace(/\/$/, "")}/chat/completions`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.AI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.AI_MODEL,
        messages: [
          { role: "system", content: "Sen Jarvis adında, Türkçe konuşan, nazik ve faydalı bir kişisel asistansın. Gerçek dünyada yapmadığın eylemleri yaptığını iddia etme." },
          ...safeMessages
        ],
        temperature: 0.7
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(502).json({ error: data?.error?.message || "AI sağlayıcısından yanıt alınamadı." });
    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string") return res.status(502).json({ error: "AI yanıt biçimi beklenenden farklı." });
    res.json({ reply });
  } catch (err) {
    res.status(500).json({ error: "Sunucu isteği tamamlayamadı." });
  }
});
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`JARVIS hazır: http://localhost:${port}`));
