# JARVIS iPhone PWA (Türkçe)

Bu, `alpunlu12-commits/jarvis` deposunun resmî bir iOS portu değildir. iPhone Safari'de çalışıp Ana Ekran'a eklenebilen bağımsız bir başlangıç arayüzüdür. Mevcut GitHub projesinin iç koduna bağlı değildir; onu gerçek özellikleriyle birleştirmek için Windows/Mac kaynak kodlarının ayrıca incelenmesi gerekir.

## Gereksinimler
- Node.js 20 veya üzeri
- OpenAI uyumlu bir sohbet API'si ve API anahtarı
- iPhone'da Ana Ekran'a ekleme için HTTPS kullanan bir barındırma

## Bilgisayarda deneme
1. Bu klasörde terminal aç.
2. `npm install`
3. `.env.example` dosyasını `.env` olarak kopyala.
4. `.env` içindeki `AI_API_KEY` ve `AI_MODEL` değerlerini kendi sağlayıcına göre doldur. API anahtarını kimseyle paylaşma.
5. `npm start`
6. Bilgisayarda `http://localhost:3000` adresini açarak dene.

## iPhone'da kullanma
1. Uygulamayı HTTPS destekleyen bir Node.js barındırma servisine dağıt.
2. Sunucuda ortam değişkenlerini ayarla (`AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`). `.env` dosyasını GitHub'a yükleme.
3. iPhone'da Safari ile dağıtılan HTTPS adresini aç.
4. Paylaş düğmesi → **Ana Ekrana Ekle** → **Ekle**.
5. Ana ekrandaki JARVIS simgesine dokun.

## Ses
- Sesli yanıt, destekleyen tarayıcılarda cihazın konuşma sentezini kullanır.
- Mikrofonla konuşmayı metne çevirme, iOS Safari sürümüne ve tarayıcı desteğine göre değişir. Çalışmıyorsa yazı girişini kullan.
- Mikrofon erişimi için HTTPS ve tarayıcı izni gerekir.

## Güvenlik / sınırlamalar
- API anahtarı yalnızca sunucuda tutulur; istemci koduna koyma.
- Bu başlangıç projesi bilgisayarı kapatma, uygulama açma veya orijinal masaüstü Jarvis'in yeteneklerini otomatik olarak devralmaz.
- Sohbet geçmişi şu an yalnızca sayfa açıkken bellekte tutulur.
- Üretimde kimlik doğrulama, istek sınırlandırma ve maliyet kontrolü ekle.
